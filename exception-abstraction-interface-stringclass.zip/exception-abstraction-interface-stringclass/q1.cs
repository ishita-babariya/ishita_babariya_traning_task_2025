﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1.exception_handling
{
    class q1
    {
        static void Main(string[] args)
        {
            int ans;
            Console.WriteLine("Enter a first number:");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a second number:");
            int b = int.Parse(Console.ReadLine());

            try
            {
                ans = a / b;
                Console.WriteLine("The result is:" + ans);
            }
            catch(DivideByZeroException e)
            {
                Console.WriteLine("Cannot divide by zero");

            }


        }
    }
}*/
