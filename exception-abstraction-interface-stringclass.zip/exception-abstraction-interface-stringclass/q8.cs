﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1.exception_handling
{
    class q8
    {
        static void Main(string[] args)
        {
            string s = "have a nice day";

            string uppercase = s.ToUpper();
            Console.WriteLine("Upper String is:" + uppercase);

            string camelcase = s.ToLowerInvariant();
            Console.WriteLine(camelcase);
        }
    }
}*/
