﻿using Microsoft.AspNetCore.Mvc;
using Student_Three_Tier.DataContext;
using Student_Three_Tier.Entities.ViewModel;
using Student_Three_Tier.Repositories.Repositories.Interface;

namespace Student_Three_Tier.Controllers
{
    public class StudentController : Controller
    {
        private readonly IStudentRepositories _context;

        public StudentController(IStudentRepositories context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            List<StudentViewModel> stu = _context.GetStudentsList();
            return View(stu);
        }
        public IActionResult Create()
        {
            return View("Create");
        }
        [HttpPost]
        public IActionResult Create(StudentViewModel student)
        {
            if (student != null)
            {
                _context.AddStudent(student);
                return RedirectToAction("Index");
            }
            else
            {
                return View("Create");
            }
            
        }
        public IActionResult Edit(int id)
        {
            var stu=_context.Detail(id);
            return View("Edit",stu);
        }

        public IActionResult Detail(int id)
        {
            var stu = _context.Detail(id);
            return View("Detail", stu);
        }

        [HttpPost]
        public IActionResult Edit(StudentViewModel student)
        {
            if (student != null)
            {
                _context.UpdateStudent(student);
                return RedirectToAction("Index");
            }
            else
            {
                return View(Edit(student));
            }
        }
        public async Task<IActionResult> Delete(int id)
        {
            await _context.Delete(id);
            return RedirectToAction("Index");
        }
    }
}
