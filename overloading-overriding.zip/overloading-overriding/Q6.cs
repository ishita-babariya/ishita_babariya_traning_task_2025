﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1.overloading_overriding
{
    //factorial using delegate
    internal class Q6
    {
        public delegate int Factorial(int n);

        public static int Fact(int n)
        {
            int fact = 1;
            for(int i=1; i<=n; i++)
            {
                fact = fact * i;
            }
            return fact;
        }

        static void Main(string[] args)
        {
            Factorial f = new Factorial(Fact);
            int result = f(6);
            Console.WriteLine("Factorial of 6 is:" + result);
        }
    }
}*/
