﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1.overloading_overriding
{
    internal class TrafficSignal
    {
        public delegate void TrafficDel();

        public static void Yellow()
        {
            Console.WriteLine("Yellow Light Signal To Get Ready.");
        }
        public static void Red()
        {
            Console.WriteLine("Red Light Signal To Stop.");
        }
        public static void Green()
        {
            Console.WriteLine("Green Light Signal To Go.");
        }
        static void Main(string[] args)
        {
            TrafficDel td = new TrafficDel(Yellow);
            td();
            TrafficDel td1=new TrafficDel(Red);
            td1();
            TrafficDel td2 = new TrafficDel(Green);
            td2();
        }
    }
}*/
