﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1.exception_handling
{
    //even number
    class q3
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number:");
            int num = int.Parse(Console.ReadLine());
            try
            {
                if(num%2==0)
                {
                    Console.WriteLine("even number");
                }
                else
                {
                    Console.WriteLine("not even number");
                }
            }
            catch(FormatException e)
            {
                Console.WriteLine("Invalid number " + e.Message);
            }
            
        }
    }
}*/
