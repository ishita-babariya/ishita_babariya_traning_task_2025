﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1.exception_handling
{
    //abstract class
    abstract class Sum
    {
        public abstract void SumOfTwo(int a, int b);
        public abstract void SumOfThree(int a, int b, int c);

    }
    class Calculate:Sum
    {
        public override void SumOfTwo(int a, int b)
        {
            Console.WriteLine("sum of two number is:" + (a + b));
        }
        public override void SumOfThree(int a, int b, int c)
        {
            Console.WriteLine("Sum of three number is:" + (a + b + c));
        }
    }

    class q4
    {
        static void Main(string[] args)
        {
            Calculate c = new Calculate(); 
            c.SumOfTwo(10, 30);
            c.SumOfThree(20, 30, 20);

        }
    }
}*/
