﻿using Microsoft.AspNetCore.Mvc;
using Student_Three_Tier.Entities.ViewModel;
using Student_Three_Tier.Repositories.Repositories.Interface;

namespace Student_Three_Tier.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly IEmployeeRepositories _context;
        public EmployeeController(IEmployeeRepositories context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            List<EmployeeViewModel> employees = _context.GetEmployeeList();
            return View(employees);
        }
        public IActionResult Create()
        {
            return View("Create");
        }

        [HttpPost]
        public IActionResult Create(EmployeeViewModel emp)
        {
            _context.AddEmployee(emp);
            return RedirectToAction("Index");
        }

        public IActionResult Detail(int id)
        {
            var emp = _context.Detail(id);
            return View(emp);
        }

        public IActionResult Edit(int id)
        {
            var emp = _context.Detail(id);
            return View(emp);
        }

        [HttpPost]
        public IActionResult Edit(EmployeeViewModel emp)
        {
            _context.UpdateEmployee(emp);
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Delete(int id)
        {
            await _context.Delete(id);
            return RedirectToAction("Index");
        }
    }
}
