﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1.collection_class
{
    //Queue for int value in Enqueue , Dequeue,Peek,Contains and Clear
   internal class Q4
    {
        delegate void Num();
        static Queue<int> s = new Queue<int>();
        static void Enqueue()
        {
            Console.WriteLine("Enqueue number of value:");
            int e = int.Parse(Console.ReadLine());
            for (int i = 0; i < e; i++)
            {
                Console.WriteLine("Enter number:");
                int a = int.Parse(Console.ReadLine());
                s.Enqueue(a);
                Console.WriteLine("Number add  End of queue:" + a);

            }
        }
        static void Dequeue()
        {
            Console.WriteLine("Queue number of value:");
            int d = s.Dequeue();
            Console.WriteLine("Number Dequeue:" + d);
        }
        static void Peek()
        {
            Console.WriteLine("Queue number of value:");
            int d = s.Peek();
            Console.WriteLine("Number Peek:" + d);
        }
        static void Contains()
        {

            Console.WriteLine("Enter number to check:");
            int a = int.Parse(Console.ReadLine());
            if (s.Contains(a))
            {
                Console.WriteLine("Number is present in queue.");
            }
            else
            {
                Console.WriteLine("Number is not present in queue.");
            }
        }
        static void Display()
        {
            Console.WriteLine("Display student name:");
            for (int i = 0; i < s.Count; i++)
            {
                Console.WriteLine(i + "" + s.ElementAt(i));

            }
        }
        static void Clear()
        {
            s.Clear();
            Console.WriteLine("Queue cleared.");
        }
        static void Menu()
        {
            Console.WriteLine("1.Enqueue");
            Console.WriteLine("2.Dequeue");
            Console.WriteLine("3.Peek");
            Console.WriteLine("4.Contains");
            Console.WriteLine("5.Display");
            Console.WriteLine("6.Clear");

        }
        static void Main(string[] arg)
        {
            int op;
            Num num;
            do
            {
                Menu();
                Console.WriteLine("Enter your choice:");
                op = int.Parse(Console.ReadLine());
                switch (op)
                {
                    case 1:
                        num = new Num(Enqueue);
                        num();
                        break;
                    case 2:
                        num = new Num(Dequeue);
                        num();
                        break;
                    case 3:
                        num = new Num(Peek);
                        num();
                        break;
                    case 4:
                        num = new Num(Contains);
                        num();
                        break;
                    case 5:
                        num = new Num(Display);
                        num();
                        break;
                    case 6:
                        num = new Num(Clear);
                        num();
                        break;
                    default:
                        Console.WriteLine("Invalid choice");
                        break;
                }
            } while (op != 0);

        }

    }
}
