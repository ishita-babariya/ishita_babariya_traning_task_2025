﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Student_Three_Tier.DataContext;
using Student_Three_Tier.DataModel;
using Student_Three_Tier.Entities.ViewModel;
using Student_Three_Tier.Repositories.Repositories.Interface;

namespace Student_Three_Tier.Repositories.Repositories
{
    public class EmployeeRepositories:IEmployeeRepositories
    {
        private readonly ApplicationDbContext _context;

        public EmployeeRepositories(ApplicationDbContext context)
        {
            _context = context;
        }

        public List<EmployeeViewModel> GetEmployeeList()
        {
            return _context.Employees.OrderBy(x => x.Id)
                .Select(x => new EmployeeViewModel
                {
                    Id = x.Id,
                    Username = x.Username,
                    Password = x.Password,
                    Email = x.Email,
                    Number = x.Number
                }).ToList();
        }

        public void AddEmployee(EmployeeViewModel emp)
        {
            var employee = new Employee();
            employee.Username = emp.Username;
            employee.Password = emp.Password;
            employee.Email = emp.Email;
            employee.Number = emp.Number;
            _context.Employees.Add(employee);
            _context.SaveChanges();
        }

        public EmployeeViewModel Detail(int id)
        {
            var emp = _context.Employees.Where(x => x.Id == id).Select(x => new EmployeeViewModel
            {
                Username = x.Username,
                Password = x.Password,
                Email = x.Email,
                Number = x.Number
            }).FirstOrDefault();
            return emp;
        }
        
        public void UpdateEmployee(EmployeeViewModel emp)
        {
            var employee = _context.Employees.FirstOrDefault(x => x.Id == emp.Id);
            if (employee != null)
            {
                employee.Username = emp.Username;
                employee.Password = emp.Password;
                employee.Email = emp.Email;
                employee.Number = emp.Number;
                _context.Employees.Update(employee);
                _context.SaveChanges();
            }
        }

        public async Task Delete(int id)
        {
            var emp = await _context.Employees.FindAsync(id);
            _context.Employees.Remove(emp);
            await _context.SaveChangesAsync();
        }
    }
}
