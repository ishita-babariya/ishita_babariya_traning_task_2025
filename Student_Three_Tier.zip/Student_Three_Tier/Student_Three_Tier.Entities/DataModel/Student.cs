﻿using System;
using System.Collections.Generic;

namespace Student_Three_Tier.DataModel;

public partial class Student
{
    public int Id { get; set; }

    public string Name { get; set; } 

    public string Course { get; set; } 

    public string Email { get; set; } 

    public string City { get; set; }

    public string MobileNo { get; set; }

    public string EnrollmentNo { get; set; } 

    public bool IsCourseCompleted { get; set; }
}
