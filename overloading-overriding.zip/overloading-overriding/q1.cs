﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1.overloading_overriding
{
    class q1
    {
        void Sum(int a, int b)
        {
            Console.WriteLine("sum of number:" + (a + b));
        }

        void Sum(float a, float b)
        {
            Console.WriteLine("Sum of number:" + (a + b));
        }
        static void Main(string[] args)
        {
            q1 q = new q1();
            q.Sum(10, 20);
            q.Sum(10.5f, 20.6f);
            
        }
    }
}*/
