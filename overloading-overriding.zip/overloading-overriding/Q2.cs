﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1.overloading_overriding
{
    internal class Q2
    {
        void Area(int a,int b)
        {
            Console.WriteLine("Area of rectangle:" + (a + b));
        }
        void Area(int a)
        {
            Console.WriteLine("Area of square:" + (a * a));
        }
        static void Main(string[] args)
        {
            Q2 q = new Q2();
            q.Area(10, 20);
            q.Area(20);
        }
    }
}*/
