-- PROCEDURE: public.update_data(text, text)

-- DROP PROCEDURE IF EXISTS public.update_data(text, text);

CREATE OR REPLACE PROCEDURE public.update_data(
	IN old_val text,
	IN new_val text)
LANGUAGE 'plpgsql'
AS $BODY$
BEGIN
UPDATE customer SET c_name=new_val WHERE c_name=old_val;
COMMIT;
END
$BODY$;
CALL update_data('Ben','John');
ALTER PROCEDURE public.update_data(text, text)
    OWNER TO postgres;
