﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Emp_Crud.Models
{
    [Table("Employees")]
    public class Employee
    {
        [Key]
        [Column("id")]

        public int Id { get; set; }

        [Column("username")]
        public string? Username { get; set; }

        [Column("password")]
        public int Password { get; set; }

        [Column("Email")]
        public string? Email { get; set; }

        [Column("Number")]
        public int? Phone { get; set; }
    }
}
