﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Text;

namespace ConsoleApplication1.exception_handling
{
    interface Shape
    {
        void Circle(int r);
        void Triangle(int b, int h);
        void Square(int a);
    }

    class CalculateArea:Shape
    {
        public void Circle(int r)
        {
            Console.WriteLine("Area of circle:" + (3.14 * r * r));
        }
        public void Triangle(int b,int h)
        {
            Console.WriteLine("Area of Triangle:" + (0.5 * b * h));
        }
        public void Square(int a)
        {
            Console.WriteLine("Area of Square:" + (a * a));
        }
    }
    class q6
    {
        static void Main(string[] args)
        {
            CalculateArea area = new CalculateArea();
            area.Circle(20);
            area.Triangle(20, 3);
            area.Square(30);
        }
    }
}*/
