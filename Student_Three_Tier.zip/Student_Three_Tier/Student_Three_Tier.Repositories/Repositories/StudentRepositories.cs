﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Student_Three_Tier.Repositories.Repositories.Interface;
using Student_Three_Tier.Entities.ViewModel;
using Student_Three_Tier.DataContext;
using System.Security.Cryptography.X509Certificates;
using Student_Three_Tier.DataModel;


namespace Student_Three_Tier.Repositories.Repositories
{
    public class StudentRepositories: IStudentRepositories
    {
        private readonly ApplicationDbContext _context;

        public StudentRepositories(ApplicationDbContext context)
        {
            _context = context;
        }

        public List<StudentViewModel> GetStudentsList()
        {
            return _context.Students
                .OrderBy(s => s.Id)
                .Select(x => new StudentViewModel
            {
                Id=x.Id,
                Name=x.Name,
                Course=x.Course,
                Email=x.Email,
                City=x.City,
                MobileNo=x.MobileNo,
                EnrollmentNo=x.EnrollmentNo,
                IsCourseCompleted=x.IsCourseCompleted,
            }).ToList();
 
        }
        public void AddStudent(StudentViewModel student)
        {
            
            try
            {
                var stu = new Student();
                stu.Name = student.Name;
                stu.Course = student.Course;
                stu.Email = student.Email;
                stu.City = student.City;
                stu.MobileNo = student.MobileNo;
                stu.EnrollmentNo = student.EnrollmentNo;
                stu.IsCourseCompleted = student.IsCourseCompleted;
                _context.Students.Add(stu);
                _context.SaveChanges();
            }
            catch(Exception e)
            {
                return;
            }
        }

        public StudentViewModel Detail(int id)
        {
            var stu = _context.Students
                .Where(x => x.Id == id)
                .Select(x => new StudentViewModel
            {
                Name = x.Name,
                Course = x.Course,
                Email = x.Email,
                City = x.City,
                MobileNo = x.MobileNo,
                EnrollmentNo = x.EnrollmentNo,
                IsCourseCompleted = x.IsCourseCompleted
            }).FirstOrDefault();
            return stu;
        }

        public void UpdateStudent(StudentViewModel student)
        {
            var stu = _context.Students.FirstOrDefault(x => x.Id == student.Id);
            if (stu != null)
            {
                stu.Name = student.Name;
                stu.Course = student.Course;
                stu.Email = student.Email;
                stu.City = student.City;
                stu.MobileNo = student.MobileNo;
                stu.EnrollmentNo = student.EnrollmentNo;
                stu.IsCourseCompleted = student.IsCourseCompleted;
                _context.Students.Update(stu);
                _context.SaveChanges();
            }
        }

        public async Task Delete(int id)
        {
            var student = await _context.Students.FindAsync(id);
            if (student != null)
            {
                _context.Students.Remove(student);
                await _context.SaveChangesAsync();
            }
        }
    }
}
