﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1.overloading_overriding
{
    internal class Q3
    {

        void Area(int a, int b)
        {
            Console.WriteLine("Area of rectangle:" + (a + b));
        }
        void Area(int a)
        {
            Console.WriteLine("Area of square:" + (a * a));
        }
        void Area(float a)
        {
            Console.WriteLine("Area of circle:" + (3.14 * a * a));
        }
        static void Main(string[] args)
        {
            Q3 q = new Q3();
            q.Area(10, 20);
            q.Area(20);
            q.Area(25.1f);
        }
    }
}*/
