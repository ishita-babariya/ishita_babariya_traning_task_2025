﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1.overloading_overriding
{
    //method overriding

    class RBI
    {
        public virtual void CalculateInterest()
        {
            Console.WriteLine("RBI interest rate is 4%");
        }
    }
    class HDFC : RBI
    {
        override  public void CalculateInterest()
        {
            Console.WriteLine("HDFC interest rate is 5%");

        }
    }
    class SBI : RBI
    {
        override public void CalculateInterest()
        {
            Console.WriteLine("SBI interest rate is 5%");

        }
    }

    class ICICI : RBI
    {
        override public  void CalculateInterest()
        {
            Console.WriteLine("ICICI interest rate is 5%");

        }
    }
    class Q4
    {
        static void Main(string[] args)
        {
            RBI r = new RBI();
            r.CalculateInterest();
            HDFC h = new HDFC();
            h.CalculateInterest();
            SBI s = new SBI();
            s.CalculateInterest();
            ICICI i = new ICICI();
            i.CalculateInterest();
        }
    }
}*/
