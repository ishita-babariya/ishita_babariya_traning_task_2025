﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Student_Three_Tier.Entities.ViewModel;

namespace Student_Three_Tier.Repositories.Repositories.Interface
{
    public interface IStudentRepositories
    {
        List<StudentViewModel> GetStudentsList();

        public void AddStudent(StudentViewModel student);

        public StudentViewModel Detail(int id);

        public void UpdateStudent(StudentViewModel student);

        public Task Delete(int id);
    }
}
