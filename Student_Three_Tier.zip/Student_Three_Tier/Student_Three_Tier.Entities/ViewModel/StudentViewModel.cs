﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Three_Tier.Entities.ViewModel
{
    public class StudentViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage ="Please enter name")]
        public string Name { get; set; } = null!;

        [Required(ErrorMessage = "Please choose course")]

        public string Course { get; set; } = null!;

        [Required(ErrorMessage = "Please enter email")]

        public string Email { get; set; } = null!;

        [Required(ErrorMessage = "Please enter city")]

        public string City { get; set; } = null!;

        [Required(ErrorMessage = "Please enter mobile no")]

        public string MobileNo { get; set; } = null!;

        [Required(ErrorMessage = "Please enter enrollment no")]

        public string EnrollmentNo { get; set; } = null!;

        [Required(ErrorMessage = "Please check your course are completed")]

        public bool IsCourseCompleted { get; set; }
    }
}
