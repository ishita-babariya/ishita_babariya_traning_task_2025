﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Three_Tier.Entities.ViewModel
{
    public class EmployeeViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage ="Please Enter user name")]
        public string? Username { get; set; }

        [Required(ErrorMessage = "Please Enter password")]
        public int? Password { get; set; }

        [Required(ErrorMessage = "Please Enter email")]
        public string? Email { get; set; }

        [Required(ErrorMessage = "Please Enter phone number")]
        public int? Number { get; set; }
    }
}
