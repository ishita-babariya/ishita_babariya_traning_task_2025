﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1.overloading_overriding
{
    internal class Calculator
    {
        delegate double Calculate(double a, double b);

        static double Add(double a,double b)
        {
            return a + b;
        }
        static double Sub(double a,double b)
        {
            return a - b;
        }
        static double Mul(double a,double b)
        {
            return a * b;
        }

        static void Menu()
        {
            Console.WriteLine("1.Addition");
            Console.WriteLine("2.Substraction");
            Console.WriteLine("3.Multiplication");
        }
        static void Main(string[] args)
        {
            int op;
            Calculate cal;
            double a, b;
            Console.WriteLine("Enter first number:");
            a = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter second number:");
            b = double.Parse(Console.ReadLine());

            Menu();
            Console.WriteLine("Enter your choice:");
            op = int.Parse(Console.ReadLine());
            switch(op)
            {
                case 1:
                    cal = new Calculate(Add);
                    Console.WriteLine("Addition is:" + cal(a, b));
                    break;
                case 2:
                    cal = new Calculate(Sub);
                    Console.WriteLine("Substraction is:" + cal(a, b));
                    break;
                case 3:
                    cal = new Calculate(Mul);
                    Console.WriteLine("Multiplication is:" + cal(a, b));
                    break;
                default:
                    Console.WriteLine("Invalid choice");
                    return;
            }
        }
    }
}*/
