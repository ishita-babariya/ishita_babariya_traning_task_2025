﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1.overloading_overriding
{
    class Hospital
    {
        public virtual void HospitalDetails()
        {
            Console.WriteLine("Hospital details");
        }
    }
    class Apollo:Hospital
    {
        public override void HospitalDetails()
        {
            Console.WriteLine("Apollo hospital details");
        }
    }
    class Wockhardt:Hospital
    {
        public override void HospitalDetails()
        {
            Console.WriteLine("Wockhardt hospital details");
        }
    }
    class Gokul_Superspeciality:Hospital
    {
        public override void HospitalDetails()
        {
            Console.WriteLine("Gokul Superspeciality hospital details");
        }
    }
    internal class Q5
    {
        static void Main(string[] args)
        {
            Hospital h = new Hospital();
            h.HospitalDetails();
            Apollo a = new Apollo();
            a.HospitalDetails();
            Wockhardt w = new Wockhardt();
            w.HospitalDetails();
            Gokul_Superspeciality s = new Gokul_Superspeciality();
            s.HospitalDetails();
        }

    }
}*/
