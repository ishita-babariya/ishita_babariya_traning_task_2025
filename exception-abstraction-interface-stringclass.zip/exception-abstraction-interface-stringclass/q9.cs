﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1.exception_handling
{
    //longest word in string
    class q9
    {
        static void Main(string[] args)
        {
            string str = "hello how are you?";
            Console.WriteLine(str);
            string[] word = str.Split(' ');
            string longest = word[0];
            for(int i=1; i<word.Length;i++)
            {
                if (word[i].Length > longest.Length)
                {
                    longest = word[i];
                }
             
            }
            Console.WriteLine("Longest word is:" + longest);
        }
    }
}*/
