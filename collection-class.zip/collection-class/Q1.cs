﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Globalization;

namespace ConsoleApplication1.collection_class
{
    //using Arraylist for studentName in add,remove,removerange and clear
    internal class Q1
    {
        delegate void Student();
        static ArrayList s = new ArrayList();
        static void Add()
        {
            Console.WriteLine("Add number of Student name:");
            int add = int.Parse(Console.ReadLine());
           
            for(int i=0; i<add; i++)
            {
                Console.WriteLine("Enter Student name:");
                string name = Console.ReadLine();
                s.Add(name);
                Console.WriteLine("Student name added:" + name);
            }
        }
        static void Remove()
        {
            Console.WriteLine("Remove Student name:");
            int remove = int.Parse(Console.ReadLine());
            for (int i = 0; i < remove; i++)
            {
                Console.WriteLine("Enter Student name:");
                string name = Console.ReadLine();
                s.Remove(name);
            }
        }
        static void RemoveRange()
        {
            Console.WriteLine("Remove Range of Student name:");
            int removerange = int.Parse(Console.ReadLine());
           
            for(int i=0;i<removerange;i++)
            {
                Console.WriteLine("Enter Student name:");
                string name = Console.ReadLine();
                s.RemoveRange(i, removerange);
            }
        }
        static void Clear()
        {
            Console.WriteLine("Clear student name:");
            s.Clear();
            Console.WriteLine("Student name cleared");
        }
        static void Display()
        {
            Console.WriteLine("Display student name:");
            for(int i=0; i<s.Count;i++)
            {
                Console.WriteLine(i + " " + s[i]);

            }

        }
        static void Menu()
        {
            Console.WriteLine("1.Add student name:");
            Console.WriteLine("2.Remove student name:");
            Console.WriteLine("3.Remove Range student name:");
            Console.WriteLine("4.Display student name:");
            Console.WriteLine("5.clear student name:");
        }
        static void Main(string[] args)
        {
            int ch;
            Student stu;
            do
            {
                Menu();
                Console.WriteLine("Enter your choice:");
                ch = int.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        stu = new Student(Add);
                        stu();
                        break;
                    case 2:
                        stu = new Student(Remove);
                        stu();
                        break;
                    case 3:
                        stu = new Student(RemoveRange);
                        stu();
                        break;
                    case 4:
                        stu = new Student(Display);
                        stu();
                        break;
                    case 5:
                        stu = new Student(Clear);
                        stu();
                        break;
                    default:
                        Console.WriteLine("Inavlid choice");
                        break;
                }

            } while (ch != 0);
        }
    }
}
