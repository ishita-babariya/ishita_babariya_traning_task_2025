﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1.collection_class
{
    //using stack for int value in push,pop,peek,contains and clear
    internal class Q3
    {
        delegate void Number();

        static Stack<int> s = new Stack<int>();
        static void Push()
        {
            Console.WriteLine("Push number of value:");
            int push = int.Parse(Console.ReadLine());
            for(int i=0; i<push; i++)
            {
                Console.WriteLine("Enter number:");
                int a = int.Parse(Console.ReadLine());
                s.Push(a);
                Console.WriteLine("Number pushed:" + a);
            }
        }
        static void Pop()
        {

            Console.WriteLine(s.Pop());
        }
        static void Peek()
        {
            Console.WriteLine(s.Peek());
        }
        static void Contains()
        {
            Console.WriteLine("Enter number to check:");
            int a = int.Parse(Console.ReadLine());
            if(s.Contains(a))
            {
                Console.WriteLine("Number is present in stack.");
            }
            else
            {
                Console.WriteLine("Number is not present in stack.");
            }
        }
        static void Clear()
        {
            s.Clear();
            Console.WriteLine("Stack cleared.");
        }
        static void Menu()
        {
            Console.WriteLine("1.Push");
            Console.WriteLine("2.Pop");
            Console.WriteLine("3.Peek");
            Console.WriteLine("4.Contains");
            Console.WriteLine("5.Clear");
        }
        static void Main(string[] arg)
        {
            int op;
            Number num;
            do
            {
                Menu();
                Console.WriteLine("Enter your choice:");
                op = int.Parse(Console.ReadLine());
                switch (op)
                {
                    case 1:
                        num = new Number(Push);
                        num();
                        break;
                    case 2:
                        num = new Number(Pop);
                        num();
                        break;
                    case 3:
                        num = new Number(Peek);
                        num();
                        break;
                    case 4:
                        num = new Number(Contains);
                        num();
                        break;
                    case 5:
                        num = new Number(Clear);
                        num();
                        break;
                }
            } while (op != 0);


        }

    }
}
