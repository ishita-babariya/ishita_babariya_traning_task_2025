SELECT dept_id, MAX(salary) AS "Max_salary_of_department" FROM employee GROUP BY dept_id ORDER BY dept_id ASC;
SELECT dept_id, COUNT(e_id)  AS "Less_than_3" FROM employee GROUP BY dept_id HAVING COUNT(e_id) < 3 ORDER BY dept_id ASC;
SELECT dept_id, COUNT(e_id) AS "Total_employee" FROM employee GROUP BY dept_id ORDER BY dept_id ASC;
SELECT dept_id,SUM(salary) AS "Tatal_salary" FROM employee GROUP BY dept_id ORDER BY dept_id ASC ;

