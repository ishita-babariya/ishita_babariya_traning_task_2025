﻿using Emp_Crud.Models;
using Emp_Crud.ViewModel;
using Microsoft.AspNetCore.Mvc;

namespace Emp_Crud.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EmployeeController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            var employee = _context.Employees.ToList();
            return View(employee);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(EmployeeViewModel employee)
        {
            try
            {
                if (employee.Id > 0)
                {
                    var existingemployee = _context.Employees.Find(employee.Id);
                    existingemployee.Username = employee.Username;
                    existingemployee.Password = employee.Password;
                    existingemployee.Email = employee.Email;
                    existingemployee.Phone = employee.Phone;

                    _context.Employees.Update(existingemployee);
                }
                else
                {
                    var employees = new Employee
                    {
                        Username = employee.Username,
                        Password = employee.Password,
                        Email = employee.Email,
                        Phone = employee.Phone
                    };
                    _context.Employees.Add(employees);
                }
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            catch (Exception)
            {
                return View(employee);
            }
        }
        public IActionResult Edit(int id)
        {
            var employee = _context.Employees.FirstOrDefault(x=> x.Id==id);
            var empViewModel = new EmployeeViewModel
            {
                Id = employee.Id,
                Username = employee.Username,
                Password = employee.Password,
                Email = employee.Email,
                Phone = employee.Phone,
            };
            return View("Create",empViewModel);

        }
        public IActionResult Details(int id)
        {
            var employee = _context.Employees.FirstOrDefault(x => x.Id == id);
            var empViewmodel = new EmployeeViewModel
            {
                Id = employee.Id,
                Username = employee.Username,
                Password = employee.Password,
                Email = employee.Email,
                Phone = employee.Phone
            };
            return View(empViewmodel);
        }
        public IActionResult Delete(int id)
        {
            var employee = _context.Employees.Find(id);
            if (employee == null)
                return NotFound();
            _context.Employees.Remove(employee);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
