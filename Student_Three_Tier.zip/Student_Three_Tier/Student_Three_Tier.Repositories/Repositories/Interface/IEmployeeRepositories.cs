﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Student_Three_Tier.Entities.ViewModel;

namespace Student_Three_Tier.Repositories.Repositories.Interface
{
    public interface IEmployeeRepositories
    {
        public List<EmployeeViewModel> GetEmployeeList();

        public void AddEmployee(EmployeeViewModel emp);

        public EmployeeViewModel Detail(int id);

        public void UpdateEmployee(EmployeeViewModel emp);

        public Task Delete(int id);
    }
}
