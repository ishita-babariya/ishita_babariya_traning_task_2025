﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1.exception_handling
{
    //indexoutofrange 
    class q2
    {
        static void Main(string[] args)
        {
            int[] arr = new int[3];
            arr[0] = 20;
            arr[1] = 30;
            arr[2] = 10;
            Console.WriteLine("Enter a number:");
            int a = int.Parse(Console.ReadLine());
            try
            {
                arr[a] = 10;
                Console.WriteLine("The value is:"+arr[a]);
            }
            catch(IndexOutOfRangeException e)
            {
                Console.WriteLine("Index out of range"+e.Message);
            }
        }
    }
}*/
