-- PROCEDURE: public.insert_data(text, text, integer, integer)

-- DROP PROCEDURE IF EXISTS public.insert_data(text, text, integer, integer);

CREATE OR REPLACE PROCEDURE public.insert_data(
	IN name text,
	IN country text,
	IN grades integer,
	IN s_id integer)
LANGUAGE 'plpgsql'
AS $BODY$
BEGIN

 INSERT INTO customer(c_name,city,grade,salesman_id) VALUES(name,country,grades,s_id);

END
$BODY$;

CALL insert_data('Sem','Surat',9,3);
ALTER PROCEDURE public.insert_data(text, text, integer, integer)
    OWNER TO postgres;
