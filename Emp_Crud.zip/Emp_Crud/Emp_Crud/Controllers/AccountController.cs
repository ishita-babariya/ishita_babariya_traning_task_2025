﻿using Microsoft.AspNetCore.Mvc;
using Emp_Crud.Models;
using Emp_Crud.ViewModel;

namespace Emp_Crud.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AccountController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Login()
        {
            EmployeeViewModel employee = new EmployeeViewModel();
            return View();
        }
        [HttpPost]
        public IActionResult Login(string email,int password)
        {
            var user = _context.Employees.FirstOrDefault(x => x.Email == email);

            if(user!=null)
            {
                if (user.Password == password)
                {
                    return RedirectToAction("Index", "Employee");

                }
                else
                {
                    return View();
                }
            }
            return View();
        }
    }
}
