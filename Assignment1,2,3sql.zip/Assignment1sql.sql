SELECT * FROM Product;
SELECT "Product_id","Product_name","UnitPrice" FROM Product WHERE "UnitPrice" < 20;
SELECT "Product_id","Product_name","UnitPrice" FROM Product WHERE "UnitPrice" BETWEEN  15 AND 25;
SELECT "Product_id","Product_name","UnitPrice" FROM Product WHERE "UnitPrice" > (SELECT AVG("UnitPrice") FROM Product);
SELECT "Product_id","Product_name","UnitPrice" FROM Product ORDER BY "UnitPrice" DESC LIMIT 4 ;
SELECT "Discontinued" ,COUNT(*) AS "TotalProduct" FROM Product GROUP BY "Discontinued";
SELECT "Product_name","UntsOnOrderProd","UnitsInStock" FROM Product WHERE "UnitsInStock" < "UntsOnOrderProd";
