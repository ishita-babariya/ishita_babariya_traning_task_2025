﻿/*using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;

namespace ConsoleApplication1.exception_handling
{
    class q7
    {
        static void Main(string[] args)
        {
            string s = "hello .NET";
            string str = "Core";

            string clone = (String)s.Clone();
            Console.WriteLine("original string is:" + s);
            Console.WriteLine("clone string is:" + clone);

            string lower = (String)s.ToLower();
            Console.WriteLine("Lower string is:" + lower);

            string upper = (String)s.ToUpper();
            Console.WriteLine("Upper string is:" + upper);

            string trim = (String)s.Trim();
            Console.WriteLine("Trim string is:" + trim);

            string replace = (String)s.Replace("hello", "hi");
            Console.WriteLine("Replace string is:" + replace);

            string insert = (String)s.Insert(0, "hi");
            Console.WriteLine("Insert string is:" + insert);

            string remove = (String)s.Remove(0, 5);
            Console.WriteLine("Remove string is:" + remove);

            string substring = (String)s.Substring(0, 5);
            Console.WriteLine("Substring string is:" + substring);

            string concat = String.Concat(s, str);
            Console.WriteLine("Contact string is:" + concat);

            string join = String.Join(" ", s, str);
            Console.WriteLine("Join String is :" + join);
         

        }

    }
}*/
