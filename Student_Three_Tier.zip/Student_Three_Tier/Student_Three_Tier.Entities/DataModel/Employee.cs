﻿using System;
using System.Collections.Generic;

namespace Student_Three_Tier.DataModel;

public partial class Employee
{
    public int Id { get; set; }

    public string? Username { get; set; }

    public int? Password { get; set; }

    public string? Email { get; set; }

    public int? Number { get; set; }
}
