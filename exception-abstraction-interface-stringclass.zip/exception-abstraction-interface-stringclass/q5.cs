﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace ConsoleApplication1.exception_handling
{
    interface  Calculate
    {
         void Addition(int a, int b);
         void Substraction(int a, int b);
    }
    class Result : Calculate
    {
        public  void Addition(int a, int b)
        {
            Console.WriteLine("Addition of number is:" + (a + b));
        }
        public  void Substraction(int a, int b)
        {
            Console.WriteLine("Substraction of number is:" + (a * b));
        }

    }
    class q5
    {
        static void Main(string[] args)
        {
            Result r = new Result();
            r.Addition(10, 20);
            r.Substraction(10, 20);

        }
    }
}*/
