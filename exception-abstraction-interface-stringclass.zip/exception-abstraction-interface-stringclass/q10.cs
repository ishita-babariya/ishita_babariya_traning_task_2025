﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1.exception_handling
{
    //change the case of string
    class q10
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a character:");
            char c = char.Parse(Console.ReadLine());
            if(char.IsLower(c))
            {
                Console.WriteLine("uppercase is:" + char.ToUpper(c));
            }
            else
            {
                Console.WriteLine("lowercase is:" + char.ToLower(c));
            }


        }

    }
}
